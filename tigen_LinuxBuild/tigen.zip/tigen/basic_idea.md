* make class of different entities
* those classes are:
	- department
	- course
	- instructor
	- room
	- class_time
	- sec_class
* make a singleton data class
* `sec_class` class is going to be treated like a **gene** of _chromosome_.

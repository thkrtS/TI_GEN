#ifndef _GUARD_EXTRA_UTIL_HPP_
#define _GUARD_EXTRA_UTIL_HPP_

#include <ctime>
#include <cstdlib>

namespace util {
	//int get_random_num(size_t upto);
	int rngi(int limit);
	double rngr(double limit);
};

#endif
